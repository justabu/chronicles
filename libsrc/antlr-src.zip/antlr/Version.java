package antlr;

public class Version {  
	public static final String version    = "2";
	public static final String subversion = "7";
	public static final String patchlevel = "6";
	public static final String datestamp  = "2005-12-22";
	public static final String project_version = "2.7.6 ("+datestamp+")";
}
